//
//  LandmarksApp.swift
//  Landmarks
//
//  Created by Tejas Kashid on 04/04/24.
//

import SwiftUI

@main
struct LandmarksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
